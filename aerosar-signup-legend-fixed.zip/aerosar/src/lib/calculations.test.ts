import { describe, expect, it } from 'vitest';
import type { MissionInput } from '../types/mission';
import { calculateMission, snapshotAt, validateMission } from './calculations';
import { toLocalInput, encodeShare, decodeShare } from './share';
import { runSimulation } from './simulate';
import { parallelPattern } from './pattern';

const now = new Date('2026-01-15T12:00:00');
const base = (over: Partial<MissionInput> = {}): MissionInput => ({
  missionName: 'T', lat: '10', lon: '70', timestamp: toLocalInput(new Date(now.getTime() - 2 * 3_600_000)), uncertaintyKm: '5',
  heading: '90', speed: '120', speedUnit: 'kmh', enduranceHours: '', windDirection: '', windSpeed: '', windUnit: 'kmh', ...over });

describe('calculateMission', () => {
  it('uses speed × elapsed time and the 10% heuristic', () => {
    const r = calculateMission(base(), now);
    expect(r.distanceKm).toBeCloseTo(240, 6); expect(r.radiusKm).toBeCloseTo(29, 6);
  });
  it('caps travel at endurance', () => {
    expect(calculateMission(base({ enduranceHours: '1' }), now).distanceKm).toBeCloseTo(120, 6);
  });
  it('ignores wind unless applyWind is set', () => {
    const r = calculateMission(base({ windDirection: '270', windSpeed: '20' }), now);
    expect(r.windApplied).toBe(false); expect(r.distanceKm).toBeCloseTo(240, 6);
  });
  it('adds a tailwind to ground speed', () => {
    const r = calculateMission(base({ windDirection: '270', windSpeed: '20', applyWind: true }), now);
    expect(r.windApplied).toBe(true); expect(r.groundSpeedKmh).toBeCloseTo(140, 6); expect(r.distanceKm).toBeCloseTo(280, 6);
  });
  it('rotates ground track in a 90° crosswind', () => {
    const r = calculateMission(base({ windDirection: '180', windSpeed: '120', applyWind: true }), now);
    expect(r.trackBearingDeg).toBeCloseTo(45, 6); expect(r.groundSpeedKmh).toBeCloseTo(169.7056, 3);
  });
  it('does not apply wind when only one wind field is given', () => {
    const r = calculateMission(base({ windSpeed: '20', applyWind: true }), now);
    expect(r.windApplied).toBe(false); expect(r.warnings.some(w => w.includes('both wind direction'))).toBe(true);
  });
  it('rejects a timestamp in the future', () => {
    expect(() => calculateMission(base({ timestamp: toLocalInput(new Date(now.getTime() + 3_600_000)) }), now)).toThrow();
  });
});

describe('validateMission', () => {
  it('accepts fractional headings and rejects 360', () => {
    expect(validateMission(base({ heading: '359.5' })).ok).toBe(true);
    expect(validateMission(base({ heading: '360' })).ok).toBe(false);
  });
});

describe('snapshotAt', () => {
  it('matches the full result at the end of the timeline and the origin at zero', () => {
    const r = calculateMission(base(), now);
    expect(snapshotAt(r, r.elapsedHours).distanceKm).toBeCloseTo(r.distanceKm ?? 0, 6);
    expect(snapshotAt(r, 0).position).toEqual(r.origin);
  });
});

describe('share links', () => {
  it('round-trips a scenario and preserves elapsed time', () => {
    const input = base({ missionName: 'Ünïcode ✈', applyWind: true, windDirection: '10', windSpeed: '5' });
    const code = encodeShare(input, now)!;
    const later = new Date(now.getTime() + 86_400_000);
    const back = decodeShare(`#m=${code}`, later)!;
    expect(back.missionName).toBe('Ünïcode ✈'); expect(back.applyWind).toBe(true);
    expect(calculateMission(back, later).elapsedHours).toBeCloseTo(2, 2);
  });
  it('rejects garbage', () => { expect(decodeShare('#m=%%%')).toBeNull(); expect(decodeShare('#m=AAAA')).toBeNull(); });
});

describe('simulation and pattern', () => {
  it('is deterministic and centred near the nominal point', () => {
    const r = calculateMission(base(), now);
    const a = runSimulation(r, 200), b = runSimulation(r, 200);
    expect(a.points).toEqual(b.points); expect(a.p80Km).toBeGreaterThan(0);
  });
  it('lays parallel legs inside the envelope', () => {
    const p = parallelPattern({ lat: 10, lon: 70 }, 20, 90, 5, 180);
    expect(p.legCount).toBe(8); expect(p.path).toHaveLength(16); expect(p.hours).toBeGreaterThan(0);
  });
});
