import type { Point } from '../types/mission';
import { destination } from './geo';

export interface PatternResult { path: Point[]; legCount: number; lengthKm: number; spacingKm: number; hours: number | null }

/** Local (along, across) km offsets from `center`; `along` runs on `bearingDeg`, `across` is to its right. */
function fromLocal(center: Point, bearingDeg: number, along: number, across: number): Point {
  const dist = Math.hypot(along, across);
  if (dist < 1e-9) return center;
  return destination(center, bearingDeg + Math.atan2(across, along) * 180 / Math.PI, dist);
}

/**
 * Parallel-track ("lawnmower") legs clipped to a circle. Purely geometric: it ignores sweep width,
 * detection probability, terrain and asset limits, so it is a layout illustration, not a search plan.
 */
export function parallelPattern(center: Point, radiusKm: number, bearingDeg: number, spacingKm: number, searchSpeedKmh: number): PatternResult {
  const R = Math.max(0.1, radiusKm);
  const spacing = Math.max(spacingKm || 1, (2 * R) / 150); // cap at ~150 legs
  const count = Math.max(1, Math.floor((2 * R) / spacing));
  const first = -((count - 1) * spacing) / 2;
  const path: Point[] = []; let lengthKm = 0;
  for (let i = 0; i < count; i++) {
    const across = first + i * spacing;
    const half = Math.sqrt(Math.max(0, R * R - across * across));
    const [a0, a1] = i % 2 === 0 ? [-half, half] : [half, -half];
    path.push(fromLocal(center, bearingDeg, a0, across), fromLocal(center, bearingDeg, a1, across));
    lengthKm += 2 * half + (i > 0 ? spacing : 0);
  }
  return { path, legCount: count, lengthKm, spacingKm: spacing, hours: searchSpeedKmh > 0 ? lengthKm / searchSpeedKmh : null };
}
