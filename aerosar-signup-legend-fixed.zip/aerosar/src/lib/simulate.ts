import type { CalculationResult, Point } from '../types/mission';
import { destination, haversine } from './geo';

/** Assumed 1σ error ranges. These are illustrative inputs to a visualization, not measured statistics. */
export const SIM_HEADING_SIGMA_DEG = 10;
export const SIM_SPEED_SIGMA_FRACTION = 0.08;

export interface SimulationSummary { points: Point[]; p80Km: number; runs: number }

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), a | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashString(s: string) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

/**
 * Seeded Monte Carlo spread of possible endpoints under the assumed error ranges above.
 * Deterministic for a given scenario, so the cloud does not reshuffle on every recalculation.
 */
export function runSimulation(r: CalculationResult, runs = 500): SimulationSummary {
  const rand = mulberry32(hashString(JSON.stringify(r.input)));
  const gauss = () => Math.sqrt(-2 * Math.log(1 - rand())) * Math.cos(2 * Math.PI * rand());
  const uncertainty = Number(r.input.uncertaintyKm) || 0;
  const points: Point[] = [];
  for (let i = 0; i < runs; i++) {
    const startR = uncertainty * Math.sqrt(rand()), startB = rand() * 360;
    const start = startR > 0 ? destination(r.origin, startB, startR) : r.origin;
    const bearing = r.trackBearingDeg + gauss() * SIM_HEADING_SIGMA_DEG;
    const speed = Math.max(0, r.groundSpeedKmh * (1 + gauss() * SIM_SPEED_SIGMA_FRACTION));
    const dist = r.distanceKm === null ? 0 : speed * r.travelHours;
    points.push(dist > 0 ? destination(start, bearing, dist) : start);
  }
  const d = points.map(p => haversine(p, r.projected)).sort((a, b) => a - b);
  return { points, p80Km: d[Math.min(d.length - 1, Math.floor(d.length * 0.8))] ?? 0, runs };
}
