import { z } from 'zod';
import type { CalculationResult, MissionInput, Point } from '../types/mission';
import { circlePolygon, destination, kmh } from './geo';
const schema = z.object({
  missionName: z.string().min(1, 'Enter a mission label.'),
  lat: z.coerce.number().min(-90).max(90), lon: z.coerce.number().min(-180).max(180),
  timestamp: z.string().min(1, 'Select the last known position time.'),
  uncertaintyKm: z.coerce.number().min(0).max(500),
  // Strictly below 360 so fractional headings such as 359.5 are accepted.
  heading: z.coerce.number().min(0).max(359.999),
  speed: z.coerce.number().min(0).max(1500), enduranceHours: z.string(),
  windDirection: z.string(), windSpeed: z.string(), speedUnit: z.enum(['kt','kmh','mph']), windUnit: z.enum(['kt','kmh'])
}).superRefine((v, ctx) => {
  if (v.enduranceHours.trim() && (!Number.isFinite(Number(v.enduranceHours)) || Number(v.enduranceHours) < 0 || Number(v.enduranceHours) > 100)) ctx.addIssue({code:'custom',path:['enduranceHours'],message:'Enter endurance between 0 and 100 hours.'});
  if (v.windDirection.trim() && (!Number.isFinite(Number(v.windDirection)) || Number(v.windDirection) < 0 || Number(v.windDirection) > 359.999)) ctx.addIssue({code:'custom',path:['windDirection'],message:'Wind direction must be 0–359°.'});
  if (v.windSpeed.trim() && (!Number.isFinite(Number(v.windSpeed)) || Number(v.windSpeed) < 0 || Number(v.windSpeed) > 250)) ctx.addIssue({code:'custom',path:['windSpeed'],message:'Wind speed must be 0–250.'});
});
export function validateMission(input: MissionInput) {
  const parsed = schema.safeParse(input);
  if (parsed.success) return { ok: true as const, errors: {} as Record<string,string> };
  const errors: Record<string,string> = {};
  parsed.error.issues.forEach(i => { const k = String(i.path[0] ?? 'form'); if (!errors[k]) errors[k] = i.message; });
  return { ok: false as const, errors };
}
const toRad = (d: number) => d * Math.PI / 180;
export function calculateMission(input: MissionInput, referenceTime = new Date()): CalculationResult {
  const valid = schema.parse(input);
  const origin: Point = { lat: Number(valid.lat), lon: Number(valid.lon) };
  const last = new Date(valid.timestamp);
  if (!Number.isFinite(last.getTime())) throw new Error('Last known timestamp is invalid.');
  const elapsedMs = referenceTime.getTime() - last.getTime();
  if (elapsedMs < 0) throw new Error('Last known timestamp is in the future relative to the reference time.');
  const elapsedHours = elapsedMs / 3_600_000;
  const speedKmH = kmh(Number(valid.speed), valid.speedUnit);
  const heading = Number(valid.heading);
  const endurance = valid.enduranceHours.trim() ? Number(valid.enduranceHours) : null;
  const travelHours = endurance === null ? elapsedHours : Math.min(elapsedHours, endurance);

  // Optional wind drift: one uniform wind (direction = where it blows FROM) added to the air vector.
  const windGiven = valid.windSpeed.trim() !== '' && valid.windDirection.trim() !== '';
  const windAny = valid.windSpeed.trim() !== '' || valid.windDirection.trim() !== '';
  const windApplied = Boolean(input.applyWind) && windGiven && speedKmH > 0;
  let groundSpeedKmh = speedKmH, trackBearingDeg = heading;
  if (windApplied) {
    const windKmh = kmh(Number(valid.windSpeed), valid.windUnit);
    const toward = toRad(Number(valid.windDirection) + 180);
    const ve = speedKmH * Math.sin(toRad(heading)) + windKmh * Math.sin(toward);
    const vn = speedKmH * Math.cos(toRad(heading)) + windKmh * Math.cos(toward);
    groundSpeedKmh = Math.hypot(ve, vn);
    trackBearingDeg = (Math.atan2(ve, vn) * 180 / Math.PI + 360) % 360;
  }

  const distanceKm = speedKmH > 0 ? groundSpeedKmh * travelHours : null;
  const projected = distanceKm === null || distanceKm === 0 ? origin : destination(origin, trackBearingDeg, distanceKm);
  // Illustrative envelope only: stated position uncertainty plus a transparent 10% of nominal travel distance.
  const radiusKm = Math.max(0.25, Number(valid.uncertaintyKm) + (distanceKm ?? 0) * 0.10);
  const polygon = circlePolygon(projected, radiusKm);
  const warnings: string[] = [];
  if (elapsedHours > 24) warnings.push('The last known position is over 24 hours old; this simple projection may be highly misleading.');
  if (elapsedHours > 0 && speedKmH === 0) warnings.push('Speed is zero, so no nominal movement was projected.');
  if (endurance === null) warnings.push('Endurance was not supplied; travel is not capped by fuel or endurance.');
  if (endurance !== null && elapsedHours > endurance) warnings.push('Elapsed time exceeds entered endurance; nominal movement was capped at that endurance value.');
  if (input.applyWind && !windGiven) warnings.push('Wind drift was requested but both wind direction and wind speed are required; wind was not applied.');
  else if (windApplied) warnings.push('Wind drift is applied as one uniform wind vector added to the entered airspeed and heading. Real winds vary with altitude, position and time; this is not a validated drift model.');
  else if (windAny) warnings.push('Wind is recorded for context only and is not applied to movement. Enable "Apply wind drift" to add a simple uniform-wind vector.');
  warnings.push('This is a geometric planning envelope, not a probability contour or validated search prediction.');
  const assumptions = [
    windApplied
      ? 'Aircraft is assumed to hold the entered heading and airspeed; one constant, uniform wind is vector-added to give ground speed and ground track.'
      : 'Aircraft is assumed to maintain the entered heading and speed throughout the modeled travel interval.',
    'Nominal distance is ground speed × travel time (airspeed when wind is not applied), capped by entered endurance when provided.',
    'Envelope radius = position uncertainty + 10% of nominal distance (illustrative heuristic, not statistically calibrated).',
    'A spherical-Earth great-circle destination calculation is used for the projected point and region boundary.',
    windApplied
      ? 'Wind is a single constant vector; no live aircraft, weather, terrain, or search-resource data is used.'
      : 'Wind is not applied to the track; no live aircraft, weather, terrain, or search-resource data is used.'
  ];
  const required = [valid.missionName, valid.lat !== undefined, valid.lon !== undefined, valid.timestamp, valid.heading !== undefined, valid.speed !== undefined, valid.uncertaintyKm !== undefined];
  const completeness = Math.round(required.filter(Boolean).length / required.length * 100);
  return { calculatedAt: referenceTime.toISOString(), elapsedHours, elapsedLabel: formatElapsed(elapsedHours), distanceKm, areaKm2: Math.PI * radiusKm * radiusKm, radiusKm, projected, origin, polygon, track: distanceKm === null || distanceKm === 0 ? [origin] : [origin, projected], warnings, assumptions, completeness, windNote: windApplied ? 'Wind applied · simple vector' : windAny ? 'Wind captured · not applied' : 'No wind data supplied', input: { ...input }, windApplied, groundSpeedKmh, trackBearingDeg, travelHours };
}
/** Fills fields added after v1 so missions saved by an older build still work with the timeline and simulation. */
export function normalizeResult(r: CalculationResult): CalculationResult {
  const speed = kmh(Number(r.input.speed), r.input.speedUnit);
  const endurance = r.input.enduranceHours.trim() ? Number(r.input.enduranceHours) : null;
  return {
    ...r,
    windApplied: r.windApplied ?? false,
    groundSpeedKmh: r.groundSpeedKmh ?? speed,
    trackBearingDeg: r.trackBearingDeg ?? Number(r.input.heading),
    travelHours: r.travelHours ?? (endurance === null ? r.elapsedHours : Math.min(r.elapsedHours, endurance)),
  };
}
/** Aircraft position and envelope radius at `elapsedHours` after the last known position (same model as calculateMission). */
export function snapshotAt(r: CalculationResult, elapsedHours: number) {
  const e = Math.max(0, Math.min(elapsedHours, r.elapsedHours));
  const endurance = r.input.enduranceHours.trim() ? Number(r.input.enduranceHours) : null;
  const travel = endurance === null ? e : Math.min(e, endurance);
  const distanceKm = r.distanceKm === null ? 0 : r.groundSpeedKmh * travel;
  const position = distanceKm > 0 ? destination(r.origin, r.trackBearingDeg, distanceKm) : r.origin;
  const radiusKm = Math.max(0.25, Number(r.input.uncertaintyKm) + distanceKm * 0.10);
  return { position, radiusKm, distanceKm, elapsedLabel: formatElapsed(e), enduranceReached: endurance !== null && e > endurance };
}
export function formatElapsed(hours: number): string {
  const total = Math.floor(hours * 60), days = Math.floor(total / 1440), rem = total % 1440, h = Math.floor(rem / 60), m = rem % 60;
  return days ? `${days}d ${h}h ${m}m` : h ? `${h}h ${m}m` : `${m}m`;
}
