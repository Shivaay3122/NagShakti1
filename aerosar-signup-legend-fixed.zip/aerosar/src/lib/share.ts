import type { MissionInput } from '../types/mission';

/** Formats a Date for <input type="datetime-local"> in the *local* timezone. */
export function toLocalInput(d: Date): string {
  return new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
}

const toB64Url = (s: string) => {
  let bin = ''; new TextEncoder().encode(s).forEach(b => { bin += String.fromCharCode(b); });
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};
const fromB64Url = (s: string) => {
  const bin = atob(s.replace(/-/g, '+').replace(/_/g, '/'));
  return new TextDecoder().decode(Uint8Array.from(bin, c => c.charCodeAt(0)));
};

const STRING_KEYS = ['missionName', 'lat', 'lon', 'uncertaintyKm', 'heading', 'speed', 'enduranceHours', 'windDirection', 'windSpeed'] as const;

/**
 * Encodes the scenario for a URL hash. The absolute timestamp is replaced by the age of the
 * last known position, so a link opened later rebuilds the same elapsed time.
 */
export function encodeShare(input: MissionInput, now = new Date()): string | null {
  const ageH = (now.getTime() - new Date(input.timestamp).getTime()) / 3_600_000;
  if (!Number.isFinite(ageH) || ageH < 0) return null;
  const { timestamp: _t, ...rest } = input;
  return toB64Url(JSON.stringify({ ...rest, ageH: Math.round(ageH * 1000) / 1000 }));
}

export function decodeShare(hash: string, now = new Date()): MissionInput | null {
  const m = /^#?m=([A-Za-z0-9_-]+)$/.exec(hash);
  if (!m || m[1].length > 4000) return null;
  try {
    const p = JSON.parse(fromB64Url(m[1])) as Record<string, unknown>;
    const ageH = Number(p.ageH);
    if (!Number.isFinite(ageH) || ageH < 0 || ageH > 1000) return null;
    const out: Record<string, unknown> = {};
    for (const k of STRING_KEYS) out[k] = String(p[k] ?? '').slice(0, 120);
    out.speedUnit = p.speedUnit === 'kmh' || p.speedUnit === 'mph' ? p.speedUnit : 'kt';
    out.windUnit = p.windUnit === 'kmh' ? 'kmh' : 'kt';
    out.applyWind = p.applyWind === true;
    out.timestamp = toLocalInput(new Date(now.getTime() - ageH * 3_600_000));
    return out as unknown as MissionInput;
  } catch { return null; }
}
