import { describe, expect, it } from 'vitest';
import { circlePolygon, destination, haversine, kmh } from './geo';

describe('geo', () => {
  it('returns the start point for zero distance', () => {
    const p = destination({ lat: 12.97, lon: 77.59 }, 123, 0);
    expect(p.lat).toBeCloseTo(12.97, 9); expect(p.lon).toBeCloseTo(77.59, 9);
  });
  it('round-trips destination and haversine', () => {
    for (const bearing of [0, 45, 90, 180, 271, 359]) for (const km of [1, 50, 400, 1500]) {
      const start = { lat: 12.9716, lon: 77.5946 };
      expect(haversine(start, destination(start, bearing, km))).toBeCloseTo(km, 2);
    }
  });
  it('travels due east along a parallel-ish path and wraps longitude', () => {
    const p = destination({ lat: 0, lon: 179.5 }, 90, 111.2);
    expect(p.lon).toBeLessThan(-179);
  });
  it('converts speed units', () => {
    expect(kmh(100, 'kt')).toBeCloseTo(185.2, 3);
    expect(kmh(100, 'mph')).toBeCloseTo(160.9344, 4);
    expect(kmh(100, 'kmh')).toBe(100);
  });
  it('builds a closed ring at the requested radius', () => {
    const c = { lat: 20, lon: 70 }; const ring = circlePolygon(c, 25);
    expect(ring[0]).toEqual(ring[ring.length - 1]);
    ring.forEach(p => expect(haversine(c, p)).toBeCloseTo(25, 2));
  });
});
