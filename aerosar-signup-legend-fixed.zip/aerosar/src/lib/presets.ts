import type { MissionInput } from '../types/mission';
import { toLocalInput } from './share';

export interface Preset { id: string; label: string; build: (now?: Date) => MissionInput }
const ago = (hours: number, now: Date) => toLocalInput(new Date(now.getTime() - hours * 3_600_000));

/** All presets are fictional training scenarios. */
export const presets: Preset[] = [
  { id: 'coastal', label: 'Coastal training exercise', build: (now = new Date()) => ({
    missionName: 'DEMO-042 · Coastal training exercise', lat: '12.9716', lon: '77.5946', timestamp: ago(2.5, now),
    uncertaintyKm: '8', heading: '145', speed: '118', speedUnit: 'kt', enduranceHours: '5',
    windDirection: '230', windSpeed: '14', windUnit: 'kt', applyWind: false }) },
  { id: 'mountain', label: 'Mountain valley transit · wind on', build: (now = new Date()) => ({
    missionName: 'DEMO-017 · Mountain valley transit', lat: '31.1048', lon: '77.1734', timestamp: ago(1.5, now),
    uncertaintyKm: '4', heading: '20', speed: '95', speedUnit: 'kt', enduranceHours: '4',
    windDirection: '290', windSpeed: '22', windUnit: 'kt', applyWind: true }) },
  { id: 'ocean', label: 'Open-ocean ferry flight · wind on', build: (now = new Date()) => ({
    missionName: 'DEMO-088 · Open-ocean ferry flight', lat: '8.5', lon: '73', timestamp: ago(3.2, now),
    uncertaintyKm: '15', heading: '260', speed: '160', speedUnit: 'kt', enduranceHours: '6',
    windDirection: '60', windSpeed: '35', windUnit: 'kt', applyWind: true }) },
];
