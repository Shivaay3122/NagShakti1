import type { Point } from '../types/mission';
const R = 6371.0088;
export function destination(start: Point, bearingDeg: number, distanceKm: number): Point {
  const δ = distanceKm / R, θ = bearingDeg * Math.PI / 180;
  const φ1 = start.lat * Math.PI / 180, λ1 = start.lon * Math.PI / 180;
  const φ2 = Math.asin(Math.sin(φ1) * Math.cos(δ) + Math.cos(φ1) * Math.sin(δ) * Math.cos(θ));
  const λ2 = λ1 + Math.atan2(Math.sin(θ) * Math.sin(δ) * Math.cos(φ1), Math.cos(δ) - Math.sin(φ1) * Math.sin(φ2));
  return { lat: φ2 * 180 / Math.PI, lon: ((λ2 * 180 / Math.PI + 540) % 360) - 180 };
}
/** Returns a closed ring (first point repeated at the end) so it is valid GeoJSON as-is. */
export function circlePolygon(center: Point, radiusKm: number, steps = 72): Point[] {
  const ring = Array.from({ length: steps }, (_, i) => destination(center, i * 360 / steps, radiusKm));
  return [...ring, { ...ring[0] }];
}
export function haversine(a: Point, b: Point): number {
  const rad = (n: number) => n * Math.PI / 180;
  const dLat = rad(b.lat-a.lat), dLon = rad(b.lon-a.lon);
  const h = Math.sin(dLat/2)**2 + Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLon/2)**2;
  return 2 * R * Math.asin(Math.sqrt(Math.min(1,h)));
}
export function kmh(speed: number, unit: string): number { return unit === 'kt' ? speed * 1.852 : unit === 'mph' ? speed * 1.609344 : speed; }
