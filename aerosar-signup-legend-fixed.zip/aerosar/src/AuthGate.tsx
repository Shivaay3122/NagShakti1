import { useEffect, useState } from 'react';
import { createClient, type Session } from '@supabase/supabase-js';
import { Activity, ArrowRight, Eye, EyeOff, LockKeyhole, Mail, ShieldCheck, UserRound, X } from 'lucide-react';
import './auth.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
const supabase = supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : null;

export default function AuthGate({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const [mode, setMode] = useState<'signup' | 'login'>('signup');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [demo, setDemo] = useState(false);

  useEffect(() => {
    if (!supabase) { setReady(true); return; }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => data.subscription.unsubscribe();
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setError(''); setMessage('');
    if (!supabase) { setError('Authentication is not configured yet. Add your Supabase URL and anon key to the .env file; see README.md.'); return; }
    if (password.length < 8) { setError('Use a password with at least 8 characters.'); return; }
    setBusy(true);
    try {
      if (mode === 'signup') {
        const { data, error: authError } = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { full_name: name.trim() } } });
        if (authError) throw authError;
        if (!data.session) setMessage('Account created. Check your email inbox to confirm your address, then sign in.');
        else setMessage('Account created successfully.');
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (authError) throw authError;
      }
    } catch (e) { setError(e instanceof Error ? e.message : 'Authentication failed. Please try again.'); }
    finally { setBusy(false); }
  };

  const google = async () => {
    setError('');
    if (!supabase) { setError('Google sign-in needs Supabase configured. Follow the Authentication setup in README.md.'); return; }
    const { error: authError } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin } });
    if (authError) setError(authError.message);
  };

  if (!ready) return <div className="auth-loading"><Activity size={22} /> Preparing secure sign-in…</div>;
  if (session || demo) return <>{supabase && session && <div className="auth-session-strip"><span><span className="auth-online-dot" /> Signed in as {session.user.email}</span><button onClick={() => supabase.auth.signOut()}><X size={14} /> Sign out</button></div>}{children}</>;

  return <main className="auth-screen">
    <div className="auth-glow auth-glow-one" /><div className="auth-glow auth-glow-two" />
    <section className="auth-card">
      <div className="auth-brand"><div className="auth-logo"><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M24 3 29 19 44 27 27 28 24 45 20 28 4 24 20 20Z" fill="none" stroke="currentColor" strokeWidth="2"/><path d="M24 12 26 23 36 26 25 27 23 37 21 26 12 24 21 22Z" fill="currentColor"/></svg></div><div><strong>AERO<span>SAR</span></strong><small>MISSION CONTROL PLATFORM</small></div><span className="auth-status"><i /> SYSTEM READY</span></div>
      <div className="auth-hero"><div className="auth-eyebrow"><span /> SEARCH & RESCUE INTELLIGENCE</div><h1>{mode === 'signup' ? <>Mission planning,<br/><em>built for clarity.</em></> : <>Welcome<br/><em>back on mission.</em></>}</h1><p>Sign in to your workspace to explore mission scenarios, save your work, and keep your planning in one place.</p></div>
      <div className="auth-tabs"><button className={mode === 'signup' ? 'selected' : ''} onClick={() => {setMode('signup');setError('');setMessage('');}}>Create account</button><button className={mode === 'login' ? 'selected' : ''} onClick={() => {setMode('login');setError('');setMessage('');}}>Sign in</button></div>
      <button className="auth-google" onClick={google}><span className="google-g">G</span> Continue with Google</button>
      <div className="auth-divider"><span /> OR WITH EMAIL <span /></div>
      <form className="auth-form" onSubmit={submit}>
        {mode === 'signup' && <label>Full name<div className="auth-input"><UserRound size={17}/><input autoComplete="name" placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} required /></div></label>}
        <label>Gmail or email address<div className="auth-input"><Mail size={17}/><input type="email" autoComplete="email" placeholder="you@gmail.com" value={email} onChange={e=>setEmail(e.target.value)} required /></div></label>
        <label>Password<div className="auth-input"><LockKeyhole size={17}/><input type={showPassword ? 'text' : 'password'} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} placeholder="At least 8 characters" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required/><button className="auth-eye" type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={()=>setShowPassword(v=>!v)}>{showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}</button></div></label>
        {error && <div className="auth-error" role="alert">{error}</div>}{message && <div className="auth-message" role="status">{message}</div>}
        <button className="auth-submit" type="submit" disabled={busy}>{busy ? 'Please wait…' : mode === 'signup' ? 'Create your account' : 'Sign in to AEROSAR'} <ArrowRight size={17}/></button>
      </form>
      <div className="auth-privacy"><ShieldCheck size={16}/><span><strong>Your account, your control.</strong><br/>Passwords are handled by Supabase Auth and are never stored by this app directly.</span></div>
      {!supabase && <div className="auth-config-note"><strong>Setup required for real accounts</strong><br/>Configure Supabase in <code>.env</code> to enable email registration and Google OAuth. Until then, you can open the app in demo mode.</div>}
      <button className="auth-demo" onClick={()=>setDemo(true)}>Continue in demo mode <ArrowRight size={14}/></button>
      <footer className="auth-footer">AEROSAR IS A PROTOTYPE · NOT FOR OPERATIONAL DISPATCH</footer>
    </section>
  </main>;
}
