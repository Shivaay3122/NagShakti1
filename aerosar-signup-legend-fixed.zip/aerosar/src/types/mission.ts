export type SpeedUnit = 'kt' | 'kmh' | 'mph';
export type WindUnit = 'kt' | 'kmh';
export interface MissionInput {
  missionName: string; lat: string; lon: string; timestamp: string; uncertaintyKm: string;
  heading: string; speed: string; speedUnit: SpeedUnit; enduranceHours: string;
  windDirection: string; windSpeed: string; windUnit: WindUnit;
  /** Opt-in: vector-add one uniform wind to the aircraft velocity. Off by default. */
  applyWind?: boolean;
}
export interface Point { lat: number; lon: number }
export interface CalculationResult {
  calculatedAt: string; elapsedHours: number; elapsedLabel: string; distanceKm: number | null;
  areaKm2: number; radiusKm: number; projected: Point; origin: Point; polygon: Point[];
  track: Point[]; warnings: string[]; assumptions: string[]; completeness: number;
  windNote: string; input: MissionInput;
  /** True only when the user opted in AND both wind direction and speed were supplied. */
  windApplied: boolean;
  /** Speed over ground used for the projection (equals airspeed when wind is not applied). */
  groundSpeedKmh: number;
  /** Ground track bearing, degrees clockwise from north (equals heading when wind is not applied). */
  trackBearingDeg: number;
  /** Hours of modeled travel after the endurance cap. */
  travelHours: number;
}
export interface SavedMission { id: string; label: string; savedAt: string; input: MissionInput; result: CalculationResult }
