# AEROSAR — Aircraft Search & Rescue Intelligence

A React + TypeScript + Vite prototype for illustrating a client-side mission-input workflow, geospatial envelope, scenario comparison, local mission history, and report exports.

> **Safety:** AEROSAR is not a validated operational search-and-rescue system. Its envelope uses an illustrative heuristic (position uncertainty + 10% of nominal travel distance), is not a probability distribution, and must not be used for operational dispatch. Qualified SAR authorities and validated procedures are required for real incidents.

## Requirements
- Node.js 20+ (recommended)
- npm
- Internet connection for OpenStreetMap tiles and the optional Google Fonts stylesheet. Calculations work locally without API keys.

## Run locally

```bash
npm install
npm run dev
```

Run the unit tests (geo maths, calculation engine, share links, simulation, pattern):

```bash
npm test
```

Open the local URL printed by Vite. To build a production bundle:

```bash
npm run build
npm run preview
```

## Features
- Responsive dark Mission Control interface with a dark Leaflet theme, grid backdrop and a radar sweep over the map.
- Basemap switcher: dark (CARTO), street (OpenStreetMap), satellite (Esri). Scale bar and live cursor coordinates.
- **Timeline scrubber / play:** move the aircraft along the track and watch the envelope grow at any elapsed time.
- **Pick or drag the last known position** on the map; the envelope recalculates live.
- **Simulation cloud:** 500 seeded Monte Carlo endpoints under assumed error ranges (illustrative spread, not a probability map).
- **Search pattern:** parallel-track layout over the envelope with leg count, length and time to fly (layout only; no sweep width or detection model). Included in the GeoJSON export.
- **Optional wind drift:** opt-in uniform-wind vector addition (off by default).
- **Shareable link:** the scenario is encoded in the URL hash; the age of the last known position is preserved.
- Extra fictional scenarios, plus scenario-variant polygons drawn on the map.
- Controlled input form with field validation.
- Great-circle geographic projection and circular envelope geometry.
- Explicitly stated movement and uncertainty assumptions; wind is recorded but not applied.
- One-click fictional training mission.
- Leaflet / OpenStreetMap visualization with attribution, last-known marker, nominal track, and envelope.
- Scenario variants calculated by the same engine.
- Browser `localStorage` mission history.
- Printable HTML report, GeoJSON export, and raw JSON calculation export.
- About/limitations and local workspace settings dialogs.

## Model notes
- The timestamp entered in the `datetime-local` field is interpreted in the browser's local timezone; elapsed time is computed against the device clock. Output timestamps are UTC ISO strings.
- Nominal travel = converted speed × elapsed time, capped at entered endurance when provided.
- Projection uses a spherical-Earth great-circle destination calculation.
- Envelope radius = entered position uncertainty + 10% of nominal distance, with a 0.25 km display floor. The extra 10% is an illustrative heuristic and has not been calibrated.
- Wind is recorded only, unless "Apply wind drift" is on and both direction and speed are given. When applied, one uniform wind (direction = where it blows from) is vector-added to the entered airspeed and heading to get ground speed and ground track. This is a simplification, not a validated drift model. No live aircraft positions, weather, terrain, current, or emergency alerts are ingested.
- Simulation cloud: endpoints sample start offset within the entered uncertainty, 1σ heading error 10° and 1σ speed error 8%. These error ranges are assumptions for visualization, and the cloud is not a probability distribution.
- Search pattern: parallel legs along the ground track, clipped to the envelope circle. Geometry only.
- Share links store inputs in the URL hash (nothing is sent to a server) and rebuild the same elapsed time when opened.
- Map tiles need internet access; no paid API keys or backend are required.

## Account registration and Google sign-in

AEROSAR includes an authentication screen with email/password registration, sign-in, and Google OAuth via Supabase Auth. Authentication is intentionally **not enabled until you configure your own Supabase project**; the app offers demo mode meanwhile.

1. Create a project at [Supabase](https://supabase.com/).
2. In **Project Settings → API**, copy the Project URL and publishable/anon key.
3. Copy `.env.example` to `.env` and fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. In Supabase **Authentication → URL Configuration**, add your local development URL (for example `http://localhost:5173`) to the allowed redirect URLs.
5. To enable Gmail/Google login, configure the Google provider under **Authentication → Providers → Google** using credentials created in the Google Cloud Console. Add the Supabase callback URL shown in the provider setup to your Google OAuth client's authorized redirect URIs.
6. Restart the Vite server after editing `.env`.

Email registration may require the user to confirm their email, depending on your Supabase Auth settings. Never put a Supabase service-role key in a frontend `.env` file; only use the publishable/anon key in the browser. The mission history remains browser-local and is not cloud-synchronized by this authentication addition.
